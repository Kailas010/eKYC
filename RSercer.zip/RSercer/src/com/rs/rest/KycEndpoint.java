package com.rs.rest;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import com.rs.entity.Kyc;

/**
 * http://localhost:8082/RSercer/rest/kycs?start=0&max=1
 * http://localhost:8082/RSercer/rest/kycs/getKyc
 * http://localhost:8082/RSercer/rest/kycs/getAllKyc
 * @author Laptop
 *
 *Deploy on glassfish 4 version 
 * Eclipse Neon Java 8
 * 
 * Issues
 * 1 :MOXy exceptions in JavaEE Jersey 2.0 project
 * Solution :
 * MANIFEST.MF
 * https://stackoverflow.com/questions/33319659/moxy-exceptions-in-javaee-jersey-2-0-project
 * https://bugs.eclipse.org/bugs/show_bug.cgi?id=463169
 *I managed to get past this issue by updating the Manifest in the org.eclipse.persistence.moxy.jar file that comes with Glassfish 4.1.1, rather than downgrading to Glassfish 4.1.0

	Steps I took:
	
	Get the updated Manifest.mf file from this post (attached on 2015-03-26 06:08:50 EDT) https://bugs.eclipse.org/bugs/show_bug.cgi?id=463169
	
	Replace the Manifest.mf file in the org.eclipse.persistence.moxy.jar file with the one you downloaded. The file is found here: {c}:\glassfish4\glassfish\modules\org.eclipse.persistence.moxy.jar
	
	Restart Glassfish
 *
 */
@RequestScoped
@Path("/kycs")
@Produces("application/json")
@Consumes("application/json")
public class KycEndpoint {

	private static List<Kyc> kycList;
	static{
		
		kycList = new ArrayList<>();
		
		kycList.add(new Kyc(111111,"One"));
		kycList.add(new Kyc(222222,"Two"));

		kycList.add(new Kyc(333333,"Three"));

		kycList.add(new Kyc(444444,"Four"));

		kycList.add(new Kyc(555555,"Five"));
	}
	@GET
	@Path("/query")
	public List<Kyc> query(@QueryParam("start") final Integer startPosition,
			@QueryParam("max") final Integer maxResult) {
		 
		
		
		return kycList.subList(startPosition, maxResult);
	}
	public List<Kyc> getKycList() {
		return kycList;
	}
	public void setKycList(List<Kyc> kycList) {
		this.kycList = kycList;
	}
	
	@GET
	@Path("/getAllKyc")
	public List<Kyc> getAllKyc() {
		 System.out.println("Get ALl.......");
		return this.kycList;
	}
	
	/**
	 * http://localhost:8082/RSercer/rest/kycs/getKyc
	 * @return
	 */
	
	@GET
	@Path("/getKyc")
	public Kyc getKyc() {
		
		return new Kyc(111111,"One");
		
		
		
	}

}
