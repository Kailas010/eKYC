package com.rs.client;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

/**
 * 
 * http://localhost:8082/RSercer/rest/kycs?start=0&max=5
 * http://localhost:8082/RSercer/rest/kycs/getKyc
 * http://localhost:8082/RSercer/rest/kycs/getAll
 * 
 * @author Laptop
 *
 */

@Stateless
public class KycClient {

	private Client client;
	
	@PostConstruct
	private void instantiateClient(){
			client=Client.create();
	}
	
	public void queryKyc(int start,int max){

		System.out.println("invokeKyc");
		WebResource resource = client.resource("http://localhost:8082/RSercer/rest/kycs/query?start="+start+"&max="+max);
		//resource.getRequestBuilder().
		String jsonResponse = resource.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println("jsonResponse "+jsonResponse);
		
	}
	
	public void getAllKyc(){

		System.out.println("invokeKyc");
		WebResource resource = client.resource("http://localhost:8082/RSercer/rest/kycs/getAllKyc");
		String jsonResponse = resource.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println("jsonResponse "+jsonResponse);
		
	}
	
	
	public void getKyc(){

		System.out.println("invokeKyc");
		WebResource resource = client.resource("http://localhost:8082/RSercer/rest/kycs/getKyc");
		String jsonResponse = resource.accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println("jsonResponse "+jsonResponse);
		
	}
}
