package com.rs.bean;

import java.io.Serializable;

import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;

import com.rs.client.KycClient;


/**
 *  * http://localhost:8082/RSercer/rest/kycs/query?start=0&max=1
 * http://localhost:8082/RSercer/rest/kycs/getKyc
 * http://localhost:8082/RSercer/rest/kycs/getAll
 * @author Laptop
 *
 */
@ManagedBean(name="clientBean")
public class ClientBean implements Serializable{
	private int start;
	private int max;
	@Inject //Check @Resource
	public KycClient client;
	
	public ClientBean() {
	
	}
	
	public void queryKYC(){
		
	System.out.println("ClientBean queryKYC");	
	client.queryKyc(this.start,this.max);
	}
	
	public void getAllKYC(){
		
		System.out.println("ClientBean getAllKyc");	
		client.getAllKyc();;
	}
	
	public void getKYC(){
		
		System.out.println("ClientBean getKyc");	
		client.getKyc();;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}
	
	
	
}
